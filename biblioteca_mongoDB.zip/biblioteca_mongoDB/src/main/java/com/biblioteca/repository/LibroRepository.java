package com.biblioteca.repository;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.biblioteca.model.Libro;
public interface LibroRepository extends MongoRepository<Libro,String>{}