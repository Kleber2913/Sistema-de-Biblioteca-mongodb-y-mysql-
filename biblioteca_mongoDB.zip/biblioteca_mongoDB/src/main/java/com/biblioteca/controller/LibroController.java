package com.biblioteca.controller;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.biblioteca.model.Libro;
import com.biblioteca.repository.LibroRepository;

@RestController
@RequestMapping("/api/libros")
@CrossOrigin("*")
public class LibroController{

 @Autowired private LibroRepository repo;

 @PostMapping
 public Libro guardar(@RequestBody Libro libro){
  return repo.save(libro);
 }

 @GetMapping
 public List<Libro> listar(){
  return repo.findAll();
 }

 @DeleteMapping("/{id}")
 public void eliminar(@PathVariable String id){
  repo.deleteById(id);
 }
}